// Register form submission handler
const registrationForm = document.getElementById('registration-form');
registrationForm.addEventListener('submit', function(event) {
  event.preventDefault(); // Prevent form submission

  // Get form values
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  // Perform registration logic (replace with your own implementation)
  // For example, you can send the data to a server or perform client-side validation
  console.log('Registration Data:', email, password);

  // Display success message
  alert('Registration successful!');
});

// Flight check-in form submission handler
const checkInForm = document.getElementById('check-in-form');
checkInForm.addEventListener('submit', function(event) {
  event.preventDefault(); // Prevent form submission

  // Get form values
  const flightNumber = document.getElementById('flight-number').value;
  const flightDate = document.getElementById('flight-date').value;
  const destination = document.getElementById('destination').value;

  // Perform check-in logic (replace with your own implementation)
  // For example, you can display a boarding pass or update the user's flight status
  console.log('Check-in Data:', flightNumber, flightDate, destination);

  // Display success message
  alert('Check-in successful!');
});
